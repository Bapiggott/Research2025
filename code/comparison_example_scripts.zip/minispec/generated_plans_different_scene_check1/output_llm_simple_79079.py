import time
import asyncio
import datetime
import json
import os
import requests

from functions_gps import *

original_code = """scan_abstract('a friend?')"""
START_SAVING_URL = "http://localhost:5000/start_saving"
STOP_SAVING_URL = "http://localhost:5000/stop_saving"

async def main():
    mission_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    mission_description = "generated_plans_different_scene_check1/output_llm_simple_79079.py"
    if mission_description == "":
        n = ""
    else:
        n = '_'
    mission_directory = f"mission_{mission_description}{n}{mission_timestamp}"
    with open(__file__, 'r') as f_in:
        translated_code = f_in.read()
    start_data = {
        "mission_directory": mission_directory,
        "original_code": original_code,
        "translated_code": translated_code
    }
    requests.post(START_SAVING_URL, json=start_data)

    await connect_drone()
    await ensure_armed_and_taken_off()

    try:
            scan_abstract('approach friend?')
    except:
        print("Caught exception in plan execution.")
    await land_drone()
    requests.post(STOP_SAVING_URL)
    print("STOP_SAVING_URL")

if __name__ == '__main__':
    result = asyncio.run(main())
    current_datetime = datetime.datetime.now().isoformat()
    with open(__file__, 'r') as f_in:
        translated_code = f_in.read()
    log_data = {
        'date': current_datetime,
        'original_code': original_code,
        'translated_code': translated_code,
        'output': str(result)
    }
    with open('execution_log.json', 'a') as log_file:
        log_file.write(json.dumps(log_data) + '\n')
    print("end")
    time.sleep(5)
    os._exit(0)
