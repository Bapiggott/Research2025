import time
import asyncio
import datetime
import json
import os
import requests

from functions_gps import *

original_code = """tp("Take a camera shot") => tp(tp("Take") <= "a" <= tp("camera shot")) => tp(0 <= 1 <= tp(0)) => tp(tp("camera shot") <= "Take a" <= 0)"""
START_SAVING_URL = "http://localhost:5000/start_saving"
STOP_SAVING_URL = "http://localhost:5000/stop_saving"

async def main():
    mission_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    mission_description = "generated_plans_different_scene_check1/output_llm_simple_84084.py"
    if mission_description == "":
        n = ""
    else:
        n = '_'
    mission_directory = f"mission_{mission_description}{n}{mission_timestamp}"
    with open(__file__, 'r') as f_in:
        translated_code = f_in.read()
    start_data = {
        "mission_directory": mission_directory,
        "original_code": original_code,
        "translated_code": translated_code
    }
    requests.post(START_SAVING_URL, json=start_data)

    await connect_drone()
    await ensure_armed_and_taken_off()

    try:
            tp("Take a camera shot") = > take_picture(take_picture("Take") <= "approach" <= take_picture("camera shot")) => take_picture(0 <= 1 <= take_picture(0)) => take_picture(take_picture("camera shot") <= "Take approach" <= 0)
    except:
        print("Caught exception in plan execution.")
    await land_drone()
    requests.post(STOP_SAVING_URL)
    print("STOP_SAVING_URL")

if __name__ == '__main__':
    result = asyncio.run(main())
    current_datetime = datetime.datetime.now().isoformat()
    with open(__file__, 'r') as f_in:
        translated_code = f_in.read()
    log_data = {
        'date': current_datetime,
        'original_code': original_code,
        'translated_code': translated_code,
        'output': str(result)
    }
    with open('execution_log.json', 'a') as log_file:
        log_file.write(json.dumps(log_data) + '\n')
    print("end")
    time.sleep(5)
    os._exit(0)
