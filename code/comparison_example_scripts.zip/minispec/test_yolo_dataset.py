import argparse
import os
import glob
import requests

def main():
    parser = argparse.ArgumentParser(description="Test YOLO detection on a folder of images.")
    parser.add_argument("--images_dir", default="/home/liu/Downloads/VisDrone2019-DET-val/images", help="Path to folder containing images.")
    parser.add_argument("--yolo_server_url", default="http://localhost:5000", help="Base URL of YOLO server")
    args = parser.parse_args()

    image_files = sorted(glob.glob(os.path.join(args.images_dir, "*.*")))
    if not image_files:
        print("[ERROR] No images found in directory:", args.images_dir)
        return

    detect_endpoint = f"{args.yolo_server_url}/detect"
    print(f"[INFO] Using YOLO detect endpoint: {detect_endpoint}")

    for img_path in image_files:
        print(f"\n=== Processing: {img_path} ===")
        try:
            with open(img_path, "rb") as f:
                # POST request to YOLO server
                files = {"image": f}
                resp = requests.post(detect_endpoint, files=files, timeout=60)
            
            if resp.status_code == 200:
                data = resp.json()
                detections = data.get("detections", [])
                print("[INFO] Detections:", detections)
            else:
                print(f"[ERROR] Server responded with status: {resp.status_code}")
                print("[DETAILS]", resp.text)

        except Exception as e:
            print("[ERROR] Failed to process", img_path, "=>", e)

if __name__ == "__main__":
    main()

